
function speak(text){
    const u=new SpeechSynthesisUtterance(text);
    const voices=window.speechSynthesis.getVoices();
    const male=voices.find(v=>/male|homem|masculino/i.test(v.name)||/male/i.test(v.lang));
    if(male) u.voice=male;
    u.pitch=0.55;
    u.rate=0.95;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
}

document.getElementById('btn-login').addEventListener('click',()=>{
    const user=document.getElementById('user').value;
    const pass=document.getElementById('pass').value;
    if(user==='Renato' && pass==='1234'){
        document.getElementById('login').style.display='none';
        document.getElementById('app').style.display='block';
        speak('Bem-vindo Renato Jay');
    } else { alert('Usuário ou senha incorretos'); speak('Login falhou'); }
});

document.getElementById('btn-test-voice').addEventListener('click',()=>speak('Olá Renato Jay, como posso ajudar?'));
document.getElementById('btn-voice').addEventListener('click',()=>{
    const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!SR){alert('Reconhecimento não suportado'); return;}
    const rec=new SR();
    rec.lang='pt-PT';
    rec.onresult=(e)=>{
        const t=e.results[0][0].transcript.toLowerCase();
        alert('Você disse: '+t);
        handleCommand(t);
    };
    rec.start();
});

function handleCommand(cmd){
    if(cmd.includes('whatsapp')){
        window.open('https://wa.me/','_blank'); speak('Abrindo WhatsApp');
    } else if(cmd.includes('gps') || cmd.includes('mapa')){
        window.open('https://www.google.com/maps','_blank'); speak('Abrindo GPS');
    } else if(cmd.includes('ficheiro') || cmd.includes('arquivo')){
        alert('Abrindo explorador de ficheiros local'); speak('Abrindo ficheiros');
    } else if(cmd.includes('reconhecimento facial')){
        alert('Reconhecimento facial ativo'); speak('Reconhecimento facial ativo');
    } else {
        speak('Comando não reconhecido');
    }
}
